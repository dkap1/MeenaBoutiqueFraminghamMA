<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type='text/css' href="_/css/style.css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Payment Cancelled</title>
</head>
<body>
<h1>Your transaction has been canceled.</h1>
<a href="shop.html">Back to Shop</a>
</body>
</html>