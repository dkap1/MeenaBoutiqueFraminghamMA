-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 30, 2017 at 04:53 PM
-- Server version: 10.1.20-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id1057103_danyaalk`
--

-- --------------------------------------------------------

--
-- Table structure for table `accessories`
--

CREATE TABLE `accessories` (
  `id` int(11) NOT NULL,
  `productcode` varchar(50) NOT NULL,
  `category_id` int(11) NOT NULL,
  `product_name` varchar(300) NOT NULL,
  `image` varchar(300) NOT NULL,
  `price` int(11) NOT NULL,
  `size` varchar(20) NOT NULL,
  `qty` int(11) NOT NULL,
  `style` text NOT NULL,
  `colour` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accessories`
--

INSERT INTO `accessories` (`id`, `productcode`, `category_id`, `product_name`, `image`, `price`, `size`, `qty`, `style`, `colour`) VALUES
(11, '804055', 2, 'Embodied Silver Shoe', '13495162_500187656833855_3163497318138806267_n-2.jpg', 50, '4', 1, 'Shoe', 'Silver'),
(12, '755436', 2, 'Studded Silver Shoe ', '13508934_500187626833858_6459947171315153868_n-2.jpg', 30, '5', 2, 'Shoe', 'Silver'),
(13, '688439 ', 2, 'Studded Silver Shoe Flat', '13507211_500187590167195_131590629014064125_n-2.jpg', 20, '7', 1, 'Shoe', 'Silver'),
(14, '178169', 2, 'Studded Stone Gold Shoe', '13445462_500187676833853_479194614470819778_n-2.jpg', 65, '8', 1, 'Shoe', 'Gold'),
(15, ' 343647', 2, 'Flowery Studded Stone Shoe', '13445335_500187383500549_8244052696504025455_n.jpg', 70, '5', 1, 'Shoe', 'Gold'),
(16, ' 170026', 2, 'Stone Earring Set ', '11954591_416005445252077_3425016901774820030_n.jpg', 30, 'One Size', 1, 'Necklace ', 'Gold'),
(17, '939748', 2, 'Silver Studded Necklace Set ', '12003371_416005425252079_8710466114885198065_n.jpg', 15, 'One Size', 1, 'Necklace', 'Silver'),
(18, ' 490936', 2, 'Bridal Gold Necklace Set', '12003140_416005411918747_8472877516085112720_n.jpg', 30, 'One Size', 1, 'Necklace', 'Gold'),
(19, '731798', 2, 'Mixed Earrings Set', '11990389_416005435252078_7995754859166567960_n.jpg', 65, 'One Size', 1, 'Earring', 'Gold'),
(20, '560418', 2, 'Mixed Variety Stone Earring Set ', '12019772_416005395252082_8812106862802737743_n.jpg', 45, 'One Size', 1, 'Earring', 'Gold');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `item_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(5) NOT NULL,
  `gross_amount` float(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `txn_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payment_gross` float(10,2) NOT NULL,
  `currency_code` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `payment_status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payer_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `productcode` varchar(50) NOT NULL,
  `category_id` int(11) NOT NULL,
  `product_name` varchar(300) NOT NULL,
  `image` varchar(300) NOT NULL,
  `price` int(11) NOT NULL,
  `size` varchar(20) NOT NULL,
  `qty` int(11) NOT NULL,
  `style` text NOT NULL,
  `colour` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `productcode`, `category_id`, `product_name`, `image`, `price`, `size`, `qty`, `style`, `colour`) VALUES
(1, '972874', 1, 'Flowery Tunic ~ 972874', 'IMG_4011.jpeg', 200, 'S', 6, 'Tunic', 'Blue'),
(2, '500995', 1, 'Long Gown ~ 500995', 'IMG_2806.PNG', 700, 'L', 5, 'Long Gown', 'Blue'),
(3, '621122', 1, 'Dark Blue and Gold Lengha Choli ~ 621122', 'IMG_2808.PNG', 900, 'XL', 1, 'Lengha Choli', 'Blue'),
(4, '426359', 1, 'Red and Gold Kurti with Trousers ~ 426359', 'O4rDfmNpS3GRMXCvUw5iDw_thumb_57a.jpg', 450, 'M', 6, 'Kurti', 'Gray'),
(5, '568137', 1, 'Red and Black Tunic Long ~ 568137', 'new..jpg', 700, 'L', 5, 'Tunic ', 'Red'),
(6, ' 155150', 1, 'Purple and Gold Salwaar Kameez', 'IMG_2807.PNG', 600, 'XXL', 8, 'Salwaar Kameez ', 'Purple '),
(7, '962602', 1, 'Embroidered Gold Tunic ~ 962602', 'IMG_0027.jpg', 1500, 'XXL', 3, 'Tunic ', 'Gold'),
(8, ' 440863', 1, 'Long Dark Green Tunic ~ 440863', '6hlAZrc6QcKHQom+86CnWw_thumb_575.jpg', 450, 'XXL', 8, 'Tunic', 'Green'),
(9, '632836', 1, 'Long Blue Tunic ~632836', '5KxVtdTESNK1AB2ccZjDRA_thumb_57b.jpg', 345, 'S', 1, 'Tunic', 'Blue'),
(10, '529903', 1, 'Gold Embodied Trouser ~ 529903', 'zQLCpCxsRfmTCLhYcRfHoQ_thumb_573.jpg', 500, 'M', 8, 'Trouser ', 'Gold'),
(11, '804055', 2, 'Embodied Silver Shoe', '13495162_500187656833855_3163497318138806267_n-2.jpg', 50, '4', 1, 'Shoe', 'Silver'),
(12, '755436', 2, 'Studded Silver Shoe ', '13508934_500187626833858_6459947171315153868_n-2.jpg', 30, '5', 2, 'Shoe', 'Silver'),
(13, '688439 ', 2, 'Studded Silver Shoe Flat', '13507211_500187590167195_131590629014064125_n-2.jpg', 20, '7', 1, 'Shoe', 'Silver'),
(14, '178169', 2, 'Studded Stone Gold Shoe', '13445462_500187676833853_479194614470819778_n-2.jpg', 65, '8', 1, 'Shoe', 'Gold'),
(15, ' 343647', 2, 'Flowery Studded Stone Shoe', '13445335_500187383500549_8244052696504025455_n.jpg', 70, '5', 1, 'Shoe', 'Gold'),
(16, ' 170026', 3, 'Stone Earring Set ', '11954591_416005445252077_3425016901774820030_n.jpg', 30, '', 1, 'Necklace ', 'Gold'),
(17, '939748', 3, 'Silver Studded Necklace Set ', '12003371_416005425252079_8710466114885198065_n.jpg', 15, '', 1, 'Necklace', 'Silver'),
(18, ' 490936', 3, 'Bridal Gold Necklace Set', '12003140_416005411918747_8472877516085112720_n.jpg', 30, '', 1, 'Necklace', 'Gold'),
(19, '731798', 3, 'Mixed Earrings Set', '11990389_416005435252078_7995754859166567960_n.jpg', 65, '', 1, 'Earring', 'Gold'),
(20, '560418', 3, 'Mixed Variety Stone Earring Set ', '12019772_416005395252082_8812106862802737743_n.jpg', 45, '', 1, 'Earring', 'Gold'),
(21, '123364', 1, 'test', 'IMG_4011.jpeg', 5, 'M', 1, 'Kurti', 'Yellow');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accessories`
--
ALTER TABLE `accessories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payment_id` (`payment_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accessories`
--
ALTER TABLE `accessories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`payment_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
