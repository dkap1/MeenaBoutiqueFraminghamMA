<?php
//Database credentials
$dbHost = 'localhost';
$dbUsername = 'id1057103_danyaalk';
$dbPassword = 'danyaal';
$dbName = 'id1057103_danyaalk';

//Connect with the database
$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName) or die ('/dberror.html">');