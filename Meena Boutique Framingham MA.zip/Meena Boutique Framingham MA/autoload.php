<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
include("dbConfig.php");
$paypal_url = 'https://www.sandbox.paypal.com/cgi-bin/webscr'; //Test PayPal API URL
$paypal_email = '10d.kapadia@preston-manor.com';
//split
$content_per_page = 3;	
$group_no  = strtolower(trim(str_replace("/","",$_REQUEST['group_no'])));
$start = ceil($group_no * $content_per_page);
$sql= "SELECT distinct * FROM `products` WHERE category_id = '1'";
    if(isset($_REQUEST['style']) && $_REQUEST['style']!="") :
		$style = explode(',',url_clean($_REQUEST['style']));	
	    $sql.=" AND style IN ('".implode("','",$style)."')";
	endif;

    if(isset($_GET['colour']) && $_GET['colour']!="") :
		$colour = explode(',',url_clean($_REQUEST['colour']));	
        $sql.=" AND colour IN ('".implode("','",$colour)."')";
    endif;

    if(isset($_GET['size']) && $_GET['size']!="") :
		$size = explode(',',$_REQUEST['size']);	
        $sql.=" AND size IN ('".implode("','",$size)."')";
    endif;
	$sql.=" LIMIT $start, $content_per_page";
	$all_product=$db->query($sql);
    $rowcount=mysqli_num_rows($all_product);
	// echo $sql; exit;

    function url_clean($String)
    {
    	return str_replace('_',' ',$String); 
    }
?>

<!-- listing -->
        <?php if(isset($all_product) && count($all_product) && $rowcount > 0) : $i = 0; ?>
            <?php foreach ($all_product as $key => $products) : ?>
                <article class="col-md-4 col-sm-6">
                    <div class="thumbnail product">
                        <figure>
                            <a href="#"><img src="product_images/<?php echo $products['image']; ?>" alt="<?php echo $products['product_name']; ?>" /></a>
                        </figure>
                        <div class="caption">
                            <a href="" class="product-name"><?php echo $products['product_name']; ?></a>
                            <div class="price">USD:<?php echo $products['price']; ?>/-</div>
                            <h6>Name : <?php echo $products['product_name']; ?></h6>
                            <h6>Colour : <?php echo $products['colour']; ?></h6>
                            <h6>Size : <?php echo $products['size']; ?></h6>
                            <h6>Style : <?php echo $products['style']; ?></h6>
	                <form action="<?php echo $paypal_url; ?>" method="post">			
			<!-- Identify your business so that you can collect the payments. -->
			<input type="hidden" name="business" value="<?php echo $paypalID; ?>">
<a href="https://twitter.com/share" class="twitter-share-button" data-text="I've just bought an item from Meena Boutique Framingham MA. Check them out!" data-url="https://danyaalcoursework.000webhostapp.com" data-via="MeenaBoutiqueMA" data-show-count="false">Tweet</a><script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
          <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdanyaalcoursework.000webhostapp.com&layout=button&size=small&mobile_iframe=true&width=59&height=20&appId" width="59" height="20" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
			
			<!-- Specify a PayPal Shopping Cart Add to Cart button. -->
			<input type="hidden" name="cmd" value="_cart">
			<input type="hidden" name="add" value="1">
			
			<!-- Specify details about the item that buyers will purchase. -->
			<input type="hidden" name="item_name" value="<?php echo $products['product_name']; ?>">
			<input type="hidden" name="item_number" value="<?php echo $products['productcode']; ?>">
			<input type="hidden" name="amount" value="<?php echo $products['price']; ?>">
                     <input type="hidden" name="custom" value="<?php echo $products['style']; 
                                                                     echo $products['size'];
                                                                     echo $products['colour'] ?>">
                    
			<input type="hidden" name="currency_code" value="USD">
        
			<input type="hidden" name="currency_code" value="USD">
             <!-- Identify your business so that you can collect the payments. -->
            <input type="hidden" name="business" value="<?php echo $paypal_email; ?>">
                        
			
			<!-- Specify URLs -->
			<input type='hidden' name='cancel_return' value='https://danyaalcoursework.000webhostapp.com/cancel.php'>
			<input type='hidden' name='return' value='https://danyaalcoursework.000webhostapp.com/success.php'>
			<input type='hidden' name='notify_url' value='https://danyaalcoursework.000webhostapp.com/ipn.php'>
			
			<!-- Display the payment button. -->
			<input type="image" name="submit"
			  <input type="image" name="submit" border="0"
        src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif" alt="Add to Cart">
        <img alt="" border="0" width="1" height="1" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" >
    </form>
<?php  ?>
</div>
</body>	
<?php  ?>
</div>
</body>
</html>
						</div>			
		 
		</div>		
	</div>	
</div>
                    </div>
                </article>
            <?php $i++; endforeach; ?> 
        <?php endif; ?>
        
        <!-- /.listing -->