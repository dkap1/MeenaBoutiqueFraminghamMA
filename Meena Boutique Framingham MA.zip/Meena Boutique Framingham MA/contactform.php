<?php 
$errors = '';
$myemail = '10d.kapadia@preston-manor.com';
if(empty($_POST['name'])  || 
   empty($_POST['name1']) || 
   empty($_POST['email']) || 
   empty($_POST['phone']) ||
   empty($_POST['question'])||
   empty($_POST['productcode']))
{
    $errors .= "\n Error: all fields are required";
}

$name = $_POST['name']; 
$name1 = $_POST['name1'];
$email_address = $_POST['email']; 
$phone = $_POST['phone'];
$productcode = $_POST['productcode']; 
$question = $_POST['question'];

if (!preg_match(
"/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/i",
$email_address))
{
    $errors .= "\n Error: Invalid Email Address";
}
if (!preg_match(
"/\(\d{3}\)\d{3}-\d{4}/",$phone))
{
	$errors .= "\n Error: Invalid Phone Number";
}
if (!preg_match(
"/^[a-zA-Z]+$/",$name))
{
	$errors .= "\n Error: Invalid Name";
}
if(strlen($name)>10)
{
 $errors .= "\n Error: Your name cannot be more than 10 characters";
}
if(strlen($name)<2)
{
 $errors .= "\n Error: Your name cannot be less than 2 characters";
}
if (!preg_match(
"/^[a-zA-Z]+$/",$name1))
{
	$errors .= "\n Error: Invalid Last Name";
}
if(strlen($name1)>10)
{
 $errors .= "\n Error: Your Last Name cannot be more than 10 characters";
}
if(strlen($name1)<2)
{
 $errors .= "\n Error: Your Last Name cannot be less than 2 characters";
}
if (!preg_match(
"/^[1-9][0-9]*$/",$productcode))
{
	$errors .= "\n Error: Invalid Product Code";
}
if(strlen($productcode)>6)
{
 $errors .= "\n Error: There are no products with product codes greater than 6. Please enter a valid product code";
}
if(strlen($productcode)<2)
{
 $errors .= "\n Error: There are no products with a product code less than than 2. Please enter a valid product code ";
}

if( empty($errors))
{
	$to = $myemail; 
	$email_subject = "Contact form submission: $name $name1";
	$email_body = "You have received a new message. ".
	" Here are the details:\n 
	Name: $name $name1 \n 
	Email: $email_address \n 
	Phone: $phone \n
	Product Code: $productcode \n 
	Question: $question"; 
	
	$headers = "From: $myemail\n"; 
	$headers .= "Reply-To: $email_address";
	
	mail($to,$email_subject,$email_body,$headers);
	//redirect to the 'thank you' page
	header('Location: thankyou.html');
} 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"> 
<html>
<head>
	<title>Form</title>
</head>

<body>
<!-- This page is displayed only if there is some error -->
<?php
echo nl2br($errors);
?>


</body>
</html>